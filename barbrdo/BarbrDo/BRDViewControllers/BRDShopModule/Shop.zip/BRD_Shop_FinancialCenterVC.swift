//
//  BRD_Shop_FinancialCenterVC.swift
//  BarbrDo
//
//  Created by Paritosh Srivastava on 6/1/17.
//  Copyright © 2017 Sumit Sharma. All rights reserved.
//

import UIKit
import Charts
let KBRD_Shop_FinancialCenter_StoryboardID = "BRD_Shop_FinancialCenterVCStoryboardID"
class BRD_Shop_FinancialCenterVC: BRD_BaseViewController {

    var btnTimeEvent: Int = 0

    @IBOutlet weak var datePicker: UIDatePicker!
    @IBOutlet weak var dateView: UIView!
    @IBOutlet weak var totalAptLbl: UILabel!
    @IBOutlet weak var dateRangeTotalSaleLlbl: UILabel!
    @IBOutlet weak var endDateTf: UITextField!
    @IBOutlet weak var startdateTf: UITextField!
    @IBOutlet weak var weekAmountLbl: UILabel!
    @IBOutlet weak var totalMonthLbl: UILabel!
    @IBOutlet weak var totalAmountLbl: UILabel!
    @IBOutlet weak var chartView: BarChartView!
    var shouldHideData : Bool?
    var valueArray : [Double] = [100.0,200.0,300.0,400,500,600,700]
    var dayArray : [String] = ["Sun" , "Mon" , "Tue" , "Wed" , "Thu" , "Fri" , "Sat"]
    @IBOutlet weak var graphView: PNBarChart!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.addTopNavigationBar(title: "")
        
        chartView.chartDescription?.enabled = false
        chartView.pinchZoomEnabled = false
        chartView.drawGridBackgroundEnabled = false
        chartView.drawBarShadowEnabled = false
        chartView.drawValueAboveBarEnabled = false
        chartView.highlightFullBarEnabled = false
        chartView.isUserInteractionEnabled = false
        let leftAxisFormatter = NumberFormatter()
        leftAxisFormatter.maximumFractionDigits = 1
        leftAxisFormatter.positivePrefix = " $"
//        leftAxisFormatter.positiveSuffix = " $"
        let leftAxis: YAxis? = chartView.leftAxis
        
        leftAxis?.valueFormatter = DefaultAxisValueFormatter.init(formatter: leftAxisFormatter)
        
        leftAxis?.axisMinimum = 0.0
        // this replaces startAtZero = YES
        chartView.rightAxis.enabled = false
        let xAxis: XAxis? = chartView.xAxis
        xAxis?.labelPosition = .bottom
        
        let l: Legend? = chartView.legend
        l?.horizontalAlignment = .right
        l?.verticalAlignment = .bottom
        l?.orientation = .horizontal
        l?.drawInside = false
        l?.form = .square
        l?.formSize = 8.0
        l?.formToTextSpace = 4.0
        l?.xEntrySpace = 6.0
        
        xAxis?.drawGridLinesEnabled = false
        xAxis?.drawAxisLineEnabled = false
        let formatter1 = ChartStringFormatter()
        xAxis?.valueFormatter = formatter1
        self.chartView.legend.enabled = false

        self.updateChartData()
    }
    func updateChartData() {
//        if shouldHideData! {
//            chartView.data = nil
//            return
//        }
        setDataCount(7, range: 0)
    }
    func setDataCount(_ count: Int, range: Double) {
        var yVals = [Any]()
        for i in 0..<count {
            let val1 = valueArray[i]
            let val2 = valueArray[i]
            yVals.append(BarChartDataEntry(x: Double(i), yValues: [(val1), (val2)], icon: UIImage(named: "icon")))
        }
        var set1: BarChartDataSet? = nil
//        if (chartView.data?.dataSetCount)! > 0 {
//            set1 = (chartView.data?.dataSets[0] as? BarChartDataSet)
//            set1?.values = yVals as! [ChartDataEntry]
//            chartView.data?.notifyDataChanged()
//            chartView.notifyDataSetChanged()
//        }
//        else {
            set1 = BarChartDataSet(values: yVals as? [ChartDataEntry], label: "")
            set1?.drawIconsEnabled = false
        
        set1?.colors = [UIColor.init(colorLiteralRed: 85.0/255.0, green: 122.0/255.0, blue: 254.0/255.0, alpha: 1) ,UIColor.init(colorLiteralRed: 52.0/255.0, green: 79.0/255.0, blue: 181.0/255.0, alpha: 1)]
//        set1?.isVisible = false
            set1?.stackLabels = ["", ""]
            var dataSets = [Any]()
            dataSets.append(set1)
        
       
            let formatter = NumberFormatter()
//            formatter.maximumSignificantDigits = 0
//            formatter.textAttributesForPositiveInfinity = ["mon","sun","tue","wed","thu","fri","sat"]
            formatter.negativeSuffix = " $"
            formatter.positiveSuffix = " $"
            let data = BarChartData(dataSets: dataSets as? [IChartDataSet])
            data.setValueFont(UIFont(name: "HelveticaNeue-Light", size: CGFloat(7.0)))
//            data.setValueFormatter(DefaultValueFormatter(formatter))
//            data.setValueFormatter(formatter as! IValueFormatter)

            data.setValueTextColor(UIColor.clear)
            chartView.fitBars = true
            chartView.data = data
//        }
        
        self.datePicker.addTarget(self, action: #selector(dateChangeAction(sender:)), for: .valueChanged)

    }
    
    @IBAction func endDateAction(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
       

        if(sender.isSelected)
        {
            self.dateView.isHidden = false
        }
        else
            
        {
            self.dateView.isHidden = true
            
        }

    }
    @IBAction func startDateAction(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
     btnTimeEvent =   sender.tag
        if(sender.isSelected)
        {
        self.dateView.isHidden = false
        }
        else
        
        {
            self.dateView.isHidden = true

        }
    }
    @IBAction func cancelAction(_ sender: Any) {

        self.dateView.isHidden = true
    }
            
    @IBAction func dateAction(_ sender: UIButton) {
                 self.dateView.isHidden = true
            
        

    }
    
    func dateChangeAction(sender: UIDatePicker){
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = Date.DateFormat.EEE_MM_dd
//        let dateFormatter1 = DateFormatter()
//        dateFormatter1.dateFormat = Date.TimeFormat.hh_mm_a
        
        
        if self.btnTimeEvent == 103
        {
            self.startdateTf.text = dateFormatter.string(from: sender.date)
                   }
        else if self.btnTimeEvent == 104
        {
            self.endDateTf.text = dateFormatter.string(from: sender.date)

            
            
        }
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
